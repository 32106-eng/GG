package com.gg.trex.registry;

import com.gg.trex.GGTrex;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(GGTrex.MODID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GGTrex.MODID);

    public static final DeferredItem<Item> REX_SADDLE =
            ITEMS.registerSimpleItem("rex_saddle", new Item.Properties().stacksTo(1));

    public static final DeferredItem<DeferredSpawnEggItem> TREX_SPAWN_EGG = ITEMS.register("trex_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.TREX, 0x4F6B2A, 0xD8C38A, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> RAPTOR_SPAWN_EGG = ITEMS.register("raptor_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.RAPTOR, 0x8A5A2B, 0xF0D13A, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> DILOPHOSAURUS_SPAWN_EGG =
            ITEMS.register("dilophosaurus_spawn_egg",
                    () -> new DeferredSpawnEggItem(ModEntities.DILOPHOSAURUS, 0x5C7A3E, 0xE8832B, new Item.Properties()));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = CREATIVE_TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + GGTrex.MODID))
                    .icon(() -> new ItemStack(REX_SADDLE.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(TREX_SPAWN_EGG.get());
                        output.accept(RAPTOR_SPAWN_EGG.get());
                        output.accept(DILOPHOSAURUS_SPAWN_EGG.get());
                        output.accept(REX_SADDLE.get());
                    })
                    .build());
}
