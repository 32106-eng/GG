package com.gg.trex.entity;

import com.gg.trex.client.ClientFx;
import com.gg.trex.entity.ai.EatCarcassGoal;
import com.gg.trex.registry.ModItems;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PlayerRideableJumping;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.animation.keyframe.event.SoundKeyframeEvent;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Shared behaviour of the three dinosaurs: taming with chicken, healing, saddle, riding (with jump),
 * wild aggression, hunting prey, GeckoLib animation controllers and the client side effects
 * (dust, camera shake).
 */
public abstract class GGDinoEntity extends TamableAnimal implements GeoEntity, PlayerRideableJumping {
    private static final EntityDataAccessor<Boolean> DATA_SADDLED =
            SynchedEntityData.defineId(GGDinoEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_FEEDING =
            SynchedEntityData.defineId(GGDinoEntity.class, EntityDataSerializers.BOOLEAN);

    /** Entity events (sent server -> client, handled in {@link #handleEntityEvent(byte)}). */
    public static final byte EVENT_STOMP_LIGHT = 101;
    public static final byte EVENT_STOMP_HEAVY = 102;
    public static final byte EVENT_ROAR = 103;

    protected static final RawAnimation EAT_SEQUENCE = RawAnimation.begin().thenPlay("eat_in").thenLoop("eat");
    protected static final RawAnimation AIR_POSE = RawAnimation.begin().thenLoop("air");

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    // ---- client-only render state (read by the models) ----
    public float eatBlend;
    public float eatBlendO;
    public double procDist;
    public double procDistO;

    // ---- server state ----
    private double stepAccum;
    private int gestureCooldown = 100;
    private int effectDelay1 = -1;
    private byte effectEvent1;
    private int effectDelay2 = -1;
    private byte effectEvent2;
    protected float playerJumpPendingScale;

    protected GGDinoEntity(EntityType<? extends GGDinoEntity> type, Level level) {
        super(type, level);
        this.xpReward = this.experienceReward();
    }

    // =============================================================================================
    // species hooks (must only return constants: some are called while the Mob constructor runs)
    // =============================================================================================

    protected abstract int experienceReward();

    protected abstract double tameChance();

    protected abstract float healRaw();

    protected abstract float healCooked();

    protected abstract float seatY();

    protected abstract float seatZ();

    /** Blocks travelled per footstep (half of one walk cycle). */
    protected abstract double strideBlocks();

    protected abstract double meleeSpeed();

    protected abstract double strollSpeed();

    protected abstract double temptSpeed();

    protected abstract double playerAggroRange();

    protected abstract double preyAggroRange();

    /** Speed modifier used when walking to a carcass. */
    public abstract double carcassWalkSpeed();

    /** Distance from the dinosaur's centre to the carcass centre while eating. */
    public abstract double eatDistance();

    /** Degrees per tick the dinosaur can turn while lining up with a carcass. */
    public abstract float turnSpeed();

    protected abstract SoundEvent stepSound();

    protected abstract SoundEvent ambientSound();

    protected abstract SoundEvent hurtSound();

    protected abstract SoundEvent deathSound();

    protected abstract float pitchMin();

    protected abstract float pitchMax();

    /** Maps a keyframe sound name from the animation file ("step", "roar", "call", "eat") to a sound. */
    protected abstract SoundEvent keyframeSound(String key);

    /** 0 = no shake, 1 = light stomp, 2 = heavy stomp when walking. */
    protected abstract int footstepShake();

    /** Called every tick while idle: may start a random gesture animation. */
    protected abstract void tryIdleGesture();

    /** Register the triggerable one-shot animations of this species on the "action" controller. */
    protected abstract void registerActions(AnimationController<GGDinoEntity> action);

    protected boolean huntsCows() {
        return true;
    }

    protected boolean alertsSameType() {
        return true;
    }

    protected void addCombatGoals() {
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, this.meleeSpeed(), true));
    }

    // =============================================================================================
    // data
    // =============================================================================================

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_SADDLED, false);
        builder.define(DATA_FEEDING, false);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Saddled", this.isSaddled());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setSaddled(tag.getBoolean("Saddled"));
    }

    public boolean isSaddled() {
        return this.entityData.get(DATA_SADDLED);
    }

    public void setSaddled(boolean saddled) {
        this.entityData.set(DATA_SADDLED, saddled);
    }

    public boolean isFeeding() {
        return this.entityData.get(DATA_FEEDING);
    }

    public void setFeeding(boolean feeding) {
        this.entityData.set(DATA_FEEDING, feeding);
    }

    // =============================================================================================
    // AI
    // =============================================================================================

    private static double sq(double v) {
        return v * v;
    }

    private static boolean holdsChicken(Player player) {
        return player.isHolding(Items.CHICKEN) || player.isHolding(Items.COOKED_CHICKEN);
    }

    private static boolean isTameFood(ItemStack stack) {
        return stack.is(Items.CHICKEN) || stack.is(Items.COOKED_CHICKEN);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.addCombatGoals();
        this.goalSelector.addGoal(4, new EatCarcassGoal(this));
        this.goalSelector.addGoal(5, new TemptGoal(this, this.temptSpeed(),
                Ingredient.of(Items.CHICKEN, Items.COOKED_CHICKEN), false) {
            @Override
            public boolean canUse() {
                return !GGDinoEntity.this.isTame() && super.canUse();
            }
        });
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, this.strollSpeed()));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        // tamed: protect the owner / attack monsters nearby
        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        HurtByTargetGoal hurtBy = new HurtByTargetGoal(this);
        if (this.alertsSameType()) {
            hurtBy.setAlertOthers();
        }
        this.targetSelector.addGoal(1, hurtBy);
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Monster.class, 10, true, false,
                e -> this.isTame() && e.distanceToSqr(this) <= sq(16.0)));

        // wild: attack players that are not holding chicken, and hunt prey
        Predicate<LivingEntity> prey = e -> e.distanceToSqr(this) <= sq(this.preyAggroRange());
        this.targetSelector.addGoal(2, new WildTargetGoal<>(this, Player.class,
                e -> e instanceof Player p && !holdsChicken(p) && e.distanceToSqr(this) <= sq(this.playerAggroRange())));
        this.targetSelector.addGoal(3, new WildTargetGoal<>(this, Chicken.class, prey));
        this.targetSelector.addGoal(3, new WildTargetGoal<>(this, Pig.class, prey));
        this.targetSelector.addGoal(3, new WildTargetGoal<>(this, Sheep.class, prey));
        if (this.huntsCows()) {
            this.targetSelector.addGoal(3, new WildTargetGoal<>(this, Cow.class, prey));
        }
    }

    /** Target goal that is only active while the dinosaur is still wild. */
    private static class WildTargetGoal<T extends LivingEntity> extends NearestAttackableTargetGoal<T> {
        private final GGDinoEntity dino;

        WildTargetGoal(GGDinoEntity dino, Class<T> type, Predicate<LivingEntity> predicate) {
            super(dino, type, 10, true, false, predicate);
            this.dino = dino;
        }

        @Override
        public boolean canUse() {
            return !this.dino.isTame() && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return !this.dino.isTame() && super.canContinueToUse();
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (!this.level().isClientSide) {
            this.triggerAnim("action", "attack");
        }
        return hit;
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return false;
    }

    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        return null;
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return !this.isTame();
    }

    // =============================================================================================
    // interaction: taming, healing, saddle, riding
    // =============================================================================================

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean client = this.level().isClientSide;

        if (!this.isTame()) {
            if (isTameFood(stack)) {
                if (!client) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    if (this.random.nextDouble() < this.tameChance()) {
                        this.tame(player);
                        this.getNavigation().stop();
                        this.setTarget(null);
                        this.level().broadcastEntityEvent(this, (byte) 7);
                    } else {
                        this.level().broadcastEntityEvent(this, (byte) 6);
                    }
                }
                return InteractionResult.sidedSuccess(client);
            }
            return super.mobInteract(player, hand);
        }

        // ---- tamed ----
        if (isTameFood(stack) && this.getHealth() < this.getMaxHealth()) {
            if (!client) {
                this.heal(stack.is(Items.COOKED_CHICKEN) ? this.healCooked() : this.healRaw());
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                this.playSound(SoundEvents.GENERIC_EAT, 1.0F, 1.0F);
                if (this.level() instanceof ServerLevel server) {
                    server.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + this.getBbHeight() * 0.8,
                            this.getZ(), 5, 0.4, 0.3, 0.4, 0.02);
                }
            }
            return InteractionResult.sidedSuccess(client);
        }

        if (stack.is(ModItems.REX_SADDLE.get()) && !this.isSaddled() && this.isOwnedBy(player)) {
            if (!client) {
                this.setSaddled(true);
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                this.playSound(SoundEvents.HORSE_SADDLE, 0.8F, 1.0F);
            }
            return InteractionResult.sidedSuccess(client);
        }

        if (this.isSaddled() && !this.isVehicle() && !player.isShiftKeyDown() && !isTameFood(stack)) {
            if (!client) {
                player.startRiding(this);
            }
            return InteractionResult.sidedSuccess(client);
        }
        return super.mobInteract(player, hand);
    }

    // =============================================================================================
    // riding
    // =============================================================================================

    @Override
    public LivingEntity getControllingPassenger() {
        if (this.isSaddled() && this.getFirstPassenger() instanceof Player player) {
            return player;
        }
        return super.getControllingPassenger();
    }

    @Override
    protected Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dimensions, float partialTick) {
        return new Vec3(0.0, this.seatY(), this.seatZ()).yRot(-this.getYRot() * Mth.DEG_TO_RAD);
    }

    @Override
    protected void tickRidden(Player player, Vec3 travelVector) {
        super.tickRidden(player, travelVector);
        this.setRot(player.getYRot(), player.getXRot() * 0.5F);
        this.yRotO = this.yBodyRot = this.yHeadRot = this.getYRot();
        if (this.onGround()) {
            if (this.playerJumpPendingScale > 0.0F) {
                this.executeRidersJump(this.playerJumpPendingScale, travelVector);
            }
            this.playerJumpPendingScale = 0.0F;
        }
    }

    @Override
    protected Vec3 getRiddenInput(Player player, Vec3 travelVector) {
        float strafe = player.xxa * 0.5F;
        float forward = player.zza;
        if (forward <= 0.0F) {
            forward *= 0.25F;
        }
        return new Vec3(strafe, 0.0, forward);
    }

    @Override
    protected float getRiddenSpeed(Player player) {
        return (float) this.getAttributeValue(Attributes.MOVEMENT_SPEED);
    }

    protected void executeRidersJump(float scale, Vec3 travelVector) {
        double jump = this.getAttributeValue(Attributes.JUMP_STRENGTH) * (double) scale;
        Vec3 v = this.getDeltaMovement();
        this.setDeltaMovement(v.x, jump, v.z);
        this.hasImpulse = true;
        if (travelVector.z > 0.0) {
            float sin = Mth.sin(this.getYRot() * Mth.DEG_TO_RAD);
            float cos = Mth.cos(this.getYRot() * Mth.DEG_TO_RAD);
            this.setDeltaMovement(this.getDeltaMovement().add(-0.4F * sin * scale, 0.0, 0.4F * cos * scale));
        }
    }

    @Override
    public void onPlayerJump(int jumpPower) {
        if (this.isSaddled()) {
            if (jumpPower < 0) {
                jumpPower = 0;
            }
            if (jumpPower >= 90) {
                this.playerJumpPendingScale = 1.0F;
            } else {
                this.playerJumpPendingScale = 0.4F + 0.4F * (float) jumpPower / 90.0F;
            }
        }
    }

    @Override
    public boolean canJump() {
        return this.isSaddled();
    }

    @Override
    public void handleStartJump(int jumpPower) {
    }

    @Override
    public void handleStopJump() {
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        float[] angles = {90.0F, -90.0F, 180.0F, 0.0F};
        double dist = this.getBbWidth() * 0.5 + passenger.getBbWidth() * 0.5 + 0.6;
        for (float angle : angles) {
            float rad = (this.getYRot() + angle) * Mth.DEG_TO_RAD;
            double x = this.getX() - Mth.sin(rad) * dist;
            double z = this.getZ() + Mth.cos(rad) * dist;
            for (double dy : new double[] {0.0, 1.0, 2.0}) {
                AABB box = passenger.getLocalBoundsForPose(passenger.getPose()).move(x, this.getY() + dy, z);
                if (this.level().noCollision(passenger, box)) {
                    return new Vec3(x, this.getY() + dy, z);
                }
            }
        }
        return super.getDismountLocationForPassenger(passenger);
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
        return super.causeFallDamage(fallDistance, multiplier * 0.5F, source);
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        // the models are much longer than the collision box: avoid disappearing at the screen edge
        return super.getBoundingBoxForCulling().inflate(this.getBbWidth() * 1.5, this.getBbHeight() * 0.5, this.getBbWidth() * 1.5);
    }

    // =============================================================================================
    // sounds
    // =============================================================================================

    @Override
    public SoundEvent getAmbientSound() {
        return this.ambientSound();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return this.hurtSound();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return this.deathSound();
    }

    @Override
    public int getAmbientSoundInterval() {
        return 200;
    }

    @Override
    public float getVoicePitch() {
        return this.pitchMin() + this.random.nextFloat() * (this.pitchMax() - this.pitchMin());
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        // footsteps are handled by tick() so that they match the walk animation
    }

    // =============================================================================================
    // tick: footsteps, gestures, scheduled effects, client render state
    // =============================================================================================

    @Override
    public void tick() {
        super.tick();
        double moved = Math.hypot(this.getX() - this.xo, this.getZ() - this.zo);
        if (this.level().isClientSide) {
            this.eatBlendO = this.eatBlend;
            this.eatBlend += ((this.isFeeding() ? 1.0F : 0.0F) - this.eatBlend) * 0.08F;
            this.procDistO = this.procDist;
            if (moved < 2.0) {
                this.procDist += moved;
            }
        } else {
            this.serverTickEffects(moved);
        }
    }

    private void serverTickEffects(double moved) {
        // footsteps in rhythm with the walk cycle
        if (this.onGround() && !this.isInWater() && moved > 0.02 && moved < 2.0) {
            this.stepAccum += moved;
            double stride = this.strideBlocks();
            if (this.stepAccum >= stride) {
                this.stepAccum -= stride;
                this.onFootstep();
            }
        }
        // delayed effects (roar shock wave / stomp impact)
        if (this.effectDelay1 > 0 && --this.effectDelay1 == 0) {
            this.level().broadcastEntityEvent(this, this.effectEvent1);
            this.effectDelay1 = -1;
        }
        if (this.effectDelay2 > 0 && --this.effectDelay2 == 0) {
            this.level().broadcastEntityEvent(this, this.effectEvent2);
            this.effectDelay2 = -1;
        }
    }

    protected void onFootstep() {
        BlockState state = this.level().getBlockState(BlockPos.containing(this.getX(), this.getY() - 0.2, this.getZ()));
        if (state.isAir()) {
            return;
        }
        this.playSound(this.stepSound(), 0.9F, 0.75F + this.random.nextFloat() * 0.2F);
        int shake = this.footstepShake();
        if (shake == 2) {
            this.level().broadcastEntityEvent(this, EVENT_STOMP_HEAVY);
        } else if (shake == 1) {
            this.level().broadcastEntityEvent(this, EVENT_STOMP_LIGHT);
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.gestureCooldown > 0) {
            this.gestureCooldown--;
            return;
        }
        if (this.isFeeding() || this.isVehicle() || this.getTarget() != null || this.isInWater()
                || !this.onGround() || this.walkAnimation.speed() > 0.05F) {
            return;
        }
        this.tryIdleGesture();
    }

    /** Start a one-shot gesture animation; blocks other gestures for {@code cooldownTicks}. */
    protected void gesture(String animation, int cooldownTicks) {
        this.triggerAnim("action", animation);
        this.gestureCooldown = cooldownTicks;
    }

    /** Fire a client effect event after {@code delayTicks}. */
    protected void scheduleEffect(int delayTicks, byte event) {
        if (this.effectDelay1 <= 0) {
            this.effectDelay1 = delayTicks;
            this.effectEvent1 = event;
        } else {
            this.effectDelay2 = delayTicks;
            this.effectEvent2 = event;
        }
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == EVENT_STOMP_LIGHT) {
            ClientFx.stomp(this, false);
        } else if (id == EVENT_STOMP_HEAVY) {
            ClientFx.stomp(this, true);
        } else if (id == EVENT_ROAR) {
            ClientFx.roar(this);
        } else {
            super.handleEntityEvent(id);
        }
    }

    // =============================================================================================
    // GeckoLib
    // =============================================================================================

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        AnimationController<GGDinoEntity> pose = new AnimationController<>(this, "pose", 6, this::posePredicate);
        pose.setSoundKeyframeHandler(this::onSoundKeyframe);
        controllers.add(pose);

        AnimationController<GGDinoEntity> action = new AnimationController<>(this, "action", 4, state -> PlayState.STOP);
        action.setSoundKeyframeHandler(this::onSoundKeyframe);
        this.registerActions(action);
        controllers.add(action);
    }

    private PlayState posePredicate(AnimationState<GGDinoEntity> state) {
        if (this.isFeeding()) {
            return state.setAndContinue(EAT_SEQUENCE);
        }
        if (this.isVehicle() && !this.onGround() && !this.isInWater()) {
            return state.setAndContinue(AIR_POSE);
        }
        return PlayState.STOP;
    }

    private void onSoundKeyframe(SoundKeyframeEvent<GGDinoEntity> event) {
        GGDinoEntity dino = event.getAnimatable();
        String key = event.getKeyframeData().getSound();
        SoundEvent sound = dino.keyframeSound(key);
        if (sound == null || !dino.level().isClientSide) {
            return;
        }
        float pitch = dino.soundPitchFor(key);
        dino.level().playLocalSound(dino.getX(), dino.getY(), dino.getZ(), sound, SoundSource.NEUTRAL, 1.0F, pitch, false);
        if ("step".equals(key) && dino.footstepShake() > 0) {
            ClientFx.shake(dino, dino.footstepShake() == 2 ? 0.2F : 0.08F, 16.0F);
        }
    }

    protected float soundPitchFor(String key) {
        return 0.9F + this.random.nextFloat() * 0.2F;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
