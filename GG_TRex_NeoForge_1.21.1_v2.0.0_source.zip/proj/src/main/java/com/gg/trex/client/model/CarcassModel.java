package com.gg.trex.client.model;

import com.gg.trex.client.proc.CarcassProc;
import com.gg.trex.client.proc.Pose;
import com.gg.trex.entity.CarcassEntity;
import software.bernie.geckolib.animation.AnimationState;

/** Carcass model with the buzzing flies animation. */
public class CarcassModel extends StaticGeoModel<CarcassEntity> {
    public CarcassModel(String name) {
        super(name, "textures/entity/carcass/" + name + ".png");
    }

    @Override
    public void setCustomAnimations(CarcassEntity entity, long instanceId, AnimationState<CarcassEntity> state) {
        double life = (entity.tickCount + state.getPartialTick()) / 20.0;
        CarcassProc.flies(new Pose(this.getAnimationProcessor()), life);
    }
}
