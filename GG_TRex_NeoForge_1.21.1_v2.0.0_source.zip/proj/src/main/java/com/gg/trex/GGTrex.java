package com.gg.trex;

import com.gg.trex.event.CommonEvents;
import com.gg.trex.registry.ModEntities;
import com.gg.trex.registry.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;

/** GG T-Rex: tameable, rideable dinosaurs ported from the Bedrock add-on. */
@Mod(GGTrex.MODID)
public class GGTrex {
    public static final String MODID = "ggtrex";

    public GGTrex(IEventBus modBus) {
        ModEntities.ENTITY_TYPES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModItems.CREATIVE_TABS.register(modBus);

        modBus.addListener(CommonEvents::registerAttributes);
        modBus.addListener(CommonEvents::registerSpawnPlacements);
        NeoForge.EVENT_BUS.addListener(CommonEvents::onLivingDrops);
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
