package com.gg.trex.client.renderer;

import com.gg.trex.client.model.DinoModel;
import com.gg.trex.entity.GGDinoEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** Dinosaur renderer: GeckoLib model + emissive glowing eyes (textures/entity/NAME_glowmask.png). */
public class DinoRenderer<T extends GGDinoEntity> extends GeoEntityRenderer<T> {
    public DinoRenderer(EntityRendererProvider.Context context, DinoModel<T> model, float shadowSize) {
        super(context, model);
        this.shadowRadius = shadowSize;
        this.addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }
}
