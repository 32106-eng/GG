package com.gg.trex.client.proc;

/** Tiny Molang-style math helpers (trig works in degrees like in the Bedrock add-on). */
public final class M {
    private M() {}

    public static double sin(double degrees) {
        return Math.sin(Math.toRadians(degrees));
    }

    public static double cos(double degrees) {
        return Math.cos(Math.toRadians(degrees));
    }

    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
