package com.gg.trex.client;

import com.gg.trex.entity.GGDinoEntity;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Client-only visual effects (called from entity events). */
public final class ClientFx {
    private ClientFx() {}

    public static void shake(Entity source, float power, float range) {
        ShakeManager.add(source.position(), power, range);
    }

    /** Dust and debris kicked up by a heavy footstep or stomp. */
    public static void stomp(GGDinoEntity dino, boolean heavy) {
        Level level = dino.level();
        RandomSource random = dino.getRandom();
        BlockState state = level.getBlockState(dino.blockPosition().below());
        double width = dino.getBbWidth();
        int count = heavy ? 18 : 7;
        for (int i = 0; i < count; i++) {
            double x = dino.getX() + (random.nextDouble() - 0.5) * width;
            double z = dino.getZ() + (random.nextDouble() - 0.5) * width;
            if (!state.isAir()) {
                level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, state), x, dino.getY() + 0.1, z,
                        (random.nextDouble() - 0.5) * 0.3, 0.12 + random.nextDouble() * 0.12, (random.nextDouble() - 0.5) * 0.3);
            }
            if (heavy && i % 2 == 0) {
                level.addParticle(ParticleTypes.POOF, x, dino.getY() + 0.1, z, 0.0, 0.02, 0.0);
            }
        }
        shake(dino, heavy ? 0.5F : 0.2F, heavy ? 30.0F : 18.0F);
    }

    /** Breath cloud from the mouth plus a dust ring on the ground. */
    public static void roar(GGDinoEntity dino) {
        Level level = dino.level();
        RandomSource random = dino.getRandom();
        Vec3 look = dino.getLookAngle();
        double width = dino.getBbWidth();
        Vec3 mouth = dino.getEyePosition().add(look.x * width * 0.9, -0.4, look.z * width * 0.9);
        for (int i = 0; i < 30; i++) {
            level.addParticle(ParticleTypes.CLOUD, mouth.x, mouth.y, mouth.z,
                    look.x * 0.35 + (random.nextDouble() - 0.5) * 0.35,
                    (random.nextDouble() - 0.5) * 0.15,
                    look.z * 0.35 + (random.nextDouble() - 0.5) * 0.35);
        }
        for (int i = 0; i < 28; i++) {
            double angle = i / 28.0 * Math.PI * 2.0;
            double cos = Math.cos(angle);
            double sin = Math.sin(angle);
            level.addParticle(ParticleTypes.POOF, dino.getX() + cos * width * 0.5, dino.getY() + 0.1,
                    dino.getZ() + sin * width * 0.5, cos * 0.25, 0.02, sin * 0.25);
        }
        shake(dino, 0.65F, 40.0F);
    }
}
