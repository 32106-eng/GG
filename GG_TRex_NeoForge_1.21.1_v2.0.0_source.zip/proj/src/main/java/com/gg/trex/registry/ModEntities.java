package com.gg.trex.registry;

import com.gg.trex.GGTrex;
import com.gg.trex.entity.CarcassEntity;
import com.gg.trex.entity.DilophosaurusEntity;
import com.gg.trex.entity.RaptorEntity;
import com.gg.trex.entity.TRexEntity;
import com.gg.trex.entity.VenomSpitEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    private ModEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, GGTrex.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<TRexEntity>> TREX = ENTITY_TYPES.register("trex",
            () -> EntityType.Builder.of(TRexEntity::new, MobCategory.CREATURE)
                    .sized(3.0F, 4.5F).clientTrackingRange(10).build("trex"));

    public static final DeferredHolder<EntityType<?>, EntityType<RaptorEntity>> RAPTOR = ENTITY_TYPES.register("raptor",
            () -> EntityType.Builder.of(RaptorEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 1.7F).clientTrackingRange(10).build("raptor"));

    public static final DeferredHolder<EntityType<?>, EntityType<DilophosaurusEntity>> DILOPHOSAURUS =
            ENTITY_TYPES.register("dilophosaurus",
                    () -> EntityType.Builder.of(DilophosaurusEntity::new, MobCategory.CREATURE)
                            .sized(1.3F, 2.4F).clientTrackingRange(10).build("dilophosaurus"));

    public static final DeferredHolder<EntityType<?>, EntityType<VenomSpitEntity>> VENOM_SPIT =
            ENTITY_TYPES.register("venom_spit",
                    () -> EntityType.Builder.<VenomSpitEntity>of(VenomSpitEntity::new, MobCategory.MISC)
                            .sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(10).build("venom_spit"));

    public static final DeferredHolder<EntityType<?>, EntityType<CarcassEntity>> COW_CARCASS =
            carcass("cow_carcass", 1.6F, 0.75F);
    public static final DeferredHolder<EntityType<?>, EntityType<CarcassEntity>> PIG_CARCASS =
            carcass("pig_carcass", 1.2F, 0.6F);
    public static final DeferredHolder<EntityType<?>, EntityType<CarcassEntity>> SHEEP_CARCASS =
            carcass("sheep_carcass", 1.3F, 0.65F);
    public static final DeferredHolder<EntityType<?>, EntityType<CarcassEntity>> CHICKEN_CARCASS =
            carcass("chicken_carcass", 0.5F, 0.35F);

    private static DeferredHolder<EntityType<?>, EntityType<CarcassEntity>> carcass(String name, float w, float h) {
        return ENTITY_TYPES.register(name,
                () -> EntityType.Builder.<CarcassEntity>of(CarcassEntity::new, MobCategory.MISC)
                        .sized(w, h).clientTrackingRange(8).updateInterval(20).build(name));
    }
}
