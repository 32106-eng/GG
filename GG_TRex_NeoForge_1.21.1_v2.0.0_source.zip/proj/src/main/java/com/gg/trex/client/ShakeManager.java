package com.gg.trex.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

/** Trauma based camera shake: stomps and roars add trauma, it decays every tick. */
public final class ShakeManager {
    private ShakeManager() {}

    private static float trauma;

    public static void add(Vec3 source, float power, float range) {
        double strength = ClientConfig.shakeStrength();
        if (strength <= 0.0) {
            return;
        }
        Player player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }
        double distance = player.position().distanceTo(source);
        if (distance >= range) {
            return;
        }
        float falloff = 1.0F - (float) (distance / range);
        trauma = Math.min(1.0F, trauma + (float) (power * falloff * strength));
    }

    public static void onClientTick(ClientTickEvent.Post event) {
        trauma = Math.max(0.0F, trauma - 0.035F);
    }

    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (trauma <= 0.001F) {
            return;
        }
        float shake = trauma * trauma;
        double t = System.nanoTime() / 1.0E9;
        event.setPitch(event.getPitch() + (float) (Math.sin(t * 47.0) * 3.0 * shake));
        event.setYaw(event.getYaw() + (float) (Math.sin(t * 39.0 + 1.3) * 2.2 * shake));
        event.setRoll(event.getRoll() + (float) (Math.sin(t * 53.0 + 2.1) * 2.0 * shake));
    }
}
